require("dotenv").config();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("painel")
    .setDescription("Publica o painel oficial de filas da ESPANHA ES-SPORTS.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName("fila")
    .setDescription("Consulta a fila de uma modalidade.")
    .addStringOption(o => o.setName("modo").setDescription("Modalidade").setRequired(true)
      .addChoices(
        {name:"X1",value:"X1"},{name:"X2",value:"X2"},{name:"X3",value:"X3"},{name:"X4",value:"X4"}
      )),
  new SlashCommandBuilder()
    .setName("partida")
    .setDescription("Consulta uma partida pelo ID.")
    .addStringOption(o => o.setName("id").setDescription("ID da partida").setRequired(true)),
  new SlashCommandBuilder()
    .setName("resultado")
    .setDescription("Registra um resultado para revisão da staff.")
    .addStringOption(o => o.setName("id").setDescription("ID da partida").setRequired(true))
    .addStringOption(o => o.setName("vencedor").setDescription("Equipe vencedora").setRequired(true)
      .addChoices({name:"Equipe A",value:"A"},{name:"Equipe B",value:"B"}))
    .addStringOption(o => o.setName("prova").setDescription("Link ou descrição da prova").setRequired(true))
].map(c => c.toJSON());

async function main() {
  const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
  if (!DISCORD_TOKEN || !CLIENT_ID || !GUILD_ID) {
    console.error("Preencha DISCORD_TOKEN, CLIENT_ID e GUILD_ID no arquivo .env.");
    process.exit(1);
  }
  const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
  console.log("Comandos slash registrados no servidor!");
}
main().catch(err => { console.error(err); process.exit(1); });