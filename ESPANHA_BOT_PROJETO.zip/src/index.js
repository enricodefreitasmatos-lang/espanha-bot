require("dotenv").config();
const fs = require("node:fs");
const path = require("node:path");
const {
  Client, GatewayIntentBits, Partials, Events, ActionRowBuilder, ButtonBuilder,
  ButtonStyle, EmbedBuilder, MessageFlags
} = require("discord.js");

const required = ["DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID", "STAFF_ROLE_ID", "QUEUE_CHANNEL_ID", "MATCH_CHANNEL_ID"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Configuração ausente: ${key}. Copie .env.example para .env e preencha os campos.`);
    process.exit(1);
  }
}
const extraStaff = (process.env.EXTRA_STAFF_ROLE_IDS || "").split(",").map(s => s.trim()).filter(Boolean);
const dataPath = path.join(__dirname, "..", "data.json");
const modes = { X1: 2, X2: 4, X3: 6, X4: 8 };
const prices = ["0,50", "1,00", "2,00", "5,00", "10,00", "20,00", "50,00", "100,00", "200,00"];

function loadData() {
  try {
    const d = JSON.parse(fs.readFileSync(dataPath, "utf8"));
    return { queues: d.queues || {}, matches: d.matches || {}, nextMatchId: d.nextMatchId || 1, wins: d.wins || {} };
  } catch { return { queues: {}, matches: {}, nextMatchId: 1, wins: {} }; }
}
let db = loadData();
let saveTimer;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const tmp = dataPath + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
    fs.renameSync(tmp, dataPath);
  }, 100);
}
function queueKey(mode, price) { return `${mode}_${price.replace(",", "-")}`; }
function staff(member) {
  if (!member) return false;
  return member.permissions?.has("ManageGuild") ||
    member.roles?.cache?.has(process.env.STAFF_ROLE_ID) ||
    extraStaff.some(id => member.roles?.cache?.has(id));
}
function queueEmbed() {
  const embed = new EmbedBuilder()
    .setColor(0xB3262D)
    .setTitle("🇪🇸 ESPANHA | ES-SPORTS — Central de Filas")
    .setDescription("Escolha uma modalidade e entre na fila pelos botões abaixo.\n\n**Regras rápidas**\n• Entre apenas se estiver disponível para jogar.\n• Não entre na mesma fila com contas alternativas.\n• Resultados precisam de prova e aprovação da staff.\n• Esta versão não recebe nem confirma pagamentos.")
    .setFooter({ text: "ES-SPORTS • Jogue limpo. Respeite a staff." });
  return embed;
}
function queueRows() {
  const rows = [];
  for (const mode of Object.keys(modes)) {
    rows.push(new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`join_${mode}`).setLabel(`Entrar ${mode}`).setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`show_${mode}`).setLabel(`Ver fila ${mode}`).setStyle(ButtonStyle.Secondary)
    ));
  }
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("leave_queue").setLabel("Sair da minha fila").setStyle(ButtonStyle.Secondary)
  ));
  return rows;
}
function matchEmbed(match) {
  return new EmbedBuilder().setColor(match.status === "pending" ? 0xD9A521 : 0xB3262D)
    .setTitle(`⚔️ Partida #${match.id} • ${match.mode}`)
    .setDescription(`**Valor cadastrado:** R$ ${match.price} por jogador\n**Status:** ${match.status === "pending" ? "Aguardando resultado" : match.status === "review" ? "Resultado em revisão pela staff" : match.status === "confirmed" ? "Resultado confirmado" : "Partida cancelada"}`)
    .addFields(
      { name: "Equipe A", value: match.teamA.map(id => `<@${id}>`).join("\n") || "—", inline: true },
      { name: "Equipe B", value: match.teamB.map(id => `<@${id}>`).join("\n") || "—", inline: true },
      { name: "Prova", value: match.proof || "Ainda não enviada", inline: false },
      { name: "Vencedor informado", value: match.winner ? `Equipe ${match.winner}` : "Pendente", inline: true }
    ).setFooter({ text: "A staff deve verificar a prova antes de confirmar." });
}
function reviewButtons(id) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`confirm_${id}`).setLabel("Confirmar resultado").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`dispute_${id}`).setLabel("Marcar para revisão").setStyle(ButtonStyle.Danger)
    )
  ];
}
async function sendMatch(client, match) {
  const channel = await client.channels.fetch(process.env.MATCH_CHANNEL_ID).catch(() => null);
  if (!channel || !channel.isTextBased()) return;
  const msg = await channel.send({
    content: `⚔️ Partida #${match.id} criada! ${[...match.teamA, ...match.teamB].map(id => `<@${id}>`).join(" ")}`,
    embeds: [matchEmbed(match)]
  });
  match.messageId = msg.id;
  match.channelId = channel.id;
  save();
}
async function maybeCreateMatch(client, mode, price) {
  const key = queueKey(mode, price);
  const q = db.queues[key] || [];
  if (q.length < modes[mode]) return;
  const players = q.splice(0, modes[mode]);
  const shuffled = players.sort(() => Math.random() - 0.5);
  const half = modes[mode] / 2;
  const match = {
    id: String(db.nextMatchId++), mode, price, teamA: shuffled.slice(0, half),
    teamB: shuffled.slice(half), status: "pending", winner: null, proof: null,
    createdAt: new Date().toISOString(), reportedBy: null, confirmedBy: null
  };
  db.matches[match.id] = match;
  save();
  await sendMatch(client, match);
}
async function getMatchMessage(client, match) {
  if (!match?.channelId || !match?.messageId) return null;
  const channel = await client.channels.fetch(match.channelId).catch(() => null);
  if (!channel?.isTextBased()) return null;
  return await channel.messages.fetch(match.messageId).catch(() => null);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds], partials: [Partials.Channel] });

client.once(Events.ClientReady, c => {
  console.log(`ESPANHA BOT online como ${c.user.tag}`);
  console.log("Dados persistidos em data.json. Faça backups periódicos.");
});

client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "painel") {
        if (!staff(interaction.member)) return interaction.reply({ content: "Você não tem permissão para publicar o painel.", flags: MessageFlags.Ephemeral });
        const channel = await client.channels.fetch(process.env.QUEUE_CHANNEL_ID).catch(() => null);
        if (!channel?.isTextBased()) return interaction.reply({ content: "Canal de filas inválido. Confira QUEUE_CHANNEL_ID.", flags: MessageFlags.Ephemeral });
        await channel.send({ embeds: [queueEmbed()], components: queueRows() });
        return interaction.reply({ content: `Painel publicado em <#${channel.id}>.`, flags: MessageFlags.Ephemeral });
      }
      if (interaction.commandName === "fila") {
        const mode = interaction.options.getString("modo", true);
        const all = Object.entries(db.queues).filter(([key]) => key.startsWith(mode + "_"));
        const lines = all.map(([key, ids]) => {
          const price = key.slice(mode.length + 1).replace("-", ",");
          return `**R$ ${price}** — ${ids.length}/${modes[mode]} jogador(es)`;
        });
        return interaction.reply({ content: `**Fila ${mode}**\n${lines.join("\n") || "Nenhum jogador aguardando."}`, flags: MessageFlags.Ephemeral });
      }
      if (interaction.commandName === "partida") {
        const id = interaction.options.getString("id", true);
        const match = db.matches[id];
        if (!match) return interaction.reply({ content: "Partida não encontrada.", flags: MessageFlags.Ephemeral });
        return interaction.reply({ embeds: [matchEmbed(match)], flags: MessageFlags.Ephemeral });
      }
      if (interaction.commandName === "resultado") {
        const id = interaction.options.getString("id", true);
        const winner = interaction.options.getString("vencedor", true);
        const proof = interaction.options.getString("prova", true);
        const match = db.matches[id];
        if (!match) return interaction.reply({ content: "Partida não encontrada.", flags: MessageFlags.Ephemeral });
        const players = [...match.teamA, ...match.teamB];
        if (!players.includes(interaction.user.id) && !staff(interaction.member))
          return interaction.reply({ content: "Somente participantes ou staff podem enviar resultado.", flags: MessageFlags.Ephemeral });
        if (match.status === "confirmed" || match.status === "cancelled")
          return interaction.reply({ content: "Esta partida já foi encerrada.", flags: MessageFlags.Ephemeral });
        match.winner = winner; match.proof = proof.slice(0, 1000);
        match.status = "review"; match.reportedBy = interaction.user.id;
        save();
        const msg = await getMatchMessage(client, match);
        if (msg) await msg.edit({ embeds: [matchEmbed(match)], components: reviewButtons(id) }).catch(() => {});
        return interaction.reply({ content: `Resultado da partida #${id} enviado para revisão da staff.`, flags: MessageFlags.Ephemeral });
      }
    }
    if (!interaction.isButton()) return;
    const id = interaction.customId;
    if (id.startsWith("join_")) {
      const mode = id.slice(5);
      if (!modes[mode]) return;
      const row = Object.entries(db.queues).find(([, ids]) => ids.includes(interaction.user.id));
      if (row) return interaction.reply({ content: "Você já está em uma fila. Saia dela antes de entrar em outra.", flags: MessageFlags.Ephemeral });
      const choices = prices.map((p, i) => new ButtonBuilder().setCustomId(`price_${mode}_${p}`).setLabel(`R$ ${p}`).setStyle(i < 3 ? ButtonStyle.Secondary : ButtonStyle.Primary));
      const rows = [];
      for (let i = 0; i < choices.length; i += 5) rows.push(new ActionRowBuilder().addComponents(choices.slice(i, i + 5)));
      return interaction.reply({ content: `Escolha o valor da fila **${mode}**. O valor é apenas um registro informativo; este bot não processa pagamentos.`, components: rows, flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("price_")) {
      const parts = id.split("_");
      const mode = parts[1], price = parts.slice(2).join("_");
      if (!modes[mode] || !prices.includes(price)) return interaction.reply({ content: "Modalidade ou valor inválido.", flags: MessageFlags.Ephemeral });
      if (Object.values(db.queues).some(ids => ids.includes(interaction.user.id)))
        return interaction.reply({ content: "Você já está em uma fila.", flags: MessageFlags.Ephemeral });
      const key = queueKey(mode, price);
      db.queues[key] ||= [];
      if (db.queues[key].length >= modes[mode]) return interaction.reply({ content: "Essa fila acabou de lotar. Tente outra.", flags: MessageFlags.Ephemeral });
      db.queues[key].push(interaction.user.id);
      save();
      await interaction.reply({ content: `Você entrou na fila **${mode} — R$ ${price}** (${db.queues[key].length}/${modes[mode]}).`, flags: MessageFlags.Ephemeral });
      await maybeCreateMatch(client, mode, price);
      return;
    }
    if (id === "leave_queue") {
      let removed = false;
      for (const ids of Object.values(db.queues)) {
        const index = ids.indexOf(interaction.user.id);
        if (index >= 0) { ids.splice(index, 1); removed = true; }
      }
      save();
      return interaction.reply({ content: removed ? "Você saiu da fila." : "Você não está em nenhuma fila.", flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("show_")) {
      const mode = id.slice(5);
      const lines = Object.entries(db.queues).filter(([key]) => key.startsWith(mode + "_"))
        .map(([key, ids]) => `**R$ ${key.slice(mode.length+1).replace("-", ",")}** — ${ids.length}/${modes[mode]} jogador(es)`);
      return interaction.reply({ content: `**Filas ${mode}**\n${lines.join("\n") || "Nenhuma fila com jogadores."}`, flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("confirm_") || id.startsWith("dispute_")) {
      if (!staff(interaction.member)) return interaction.reply({ content: "Apenas a staff autorizada pode revisar resultados.", flags: MessageFlags.Ephemeral });
      const isConfirm = id.startsWith("confirm_");
      const matchId = id.slice(isConfirm ? 8 : 7);
      const match = db.matches[matchId];
      if (!match) return interaction.reply({ content: "Partida não encontrada.", flags: MessageFlags.Ephemeral });
      if (isConfirm) {
        if (!match.winner || !match.proof) return interaction.reply({ content: "Envie o resultado e a prova primeiro.", flags: MessageFlags.Ephemeral });
        if (match.status === "confirmed") return interaction.reply({ content: "Resultado já confirmado.", flags: MessageFlags.Ephemeral });
        match.status = "confirmed"; match.confirmedBy = interaction.user.id;
        const winners = match.winner === "A" ? match.teamA : match.teamB;
        for (const userId of winners) db.wins[userId] = (db.wins[userId] || 0) + 1;
        save();
        const msg = await getMatchMessage(client, match);
        if (msg) await msg.edit({ embeds: [matchEmbed(match)], components: [] }).catch(() => {});
        return interaction.reply({ content: `Resultado da partida #${matchId} confirmado. Ranking atualizado.`, flags: MessageFlags.Ephemeral });
      } else {
        match.status = "review";
        save();
        const msg = await getMatchMessage(client, match);
        if (msg) await msg.edit({ embeds: [matchEmbed(match)], components: reviewButtons(matchId) }).catch(() => {});
        return interaction.reply({ content: `Partida #${matchId} marcada para revisão. Verifique a prova e fale com os envolvidos.`, flags: MessageFlags.Ephemeral });
      }
    }
  } catch (error) {
    console.error("Erro ao processar interação:", error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: "Ocorreu um erro. Avise a staff e confira os logs do bot.", flags: MessageFlags.Ephemeral }).catch(() => {});
    }
  }
});

client.login(process.env.DISCORD_TOKEN).catch(err => {
  console.error("Não foi possível conectar. Confira DISCORD_TOKEN e a configuração do bot.", err.message);
  process.exit(1);
});