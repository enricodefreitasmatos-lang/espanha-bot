# ESPANHA BOT — ESPANHA | ES-SPORTS

Bot Discord.js v14 com filas X1/X2/X3/X4, seleção de valores, criação automática de partidas, registro de resultado e confirmação manual pela staff.

## Antes de começar

- Node.js 20 ou mais recente.
- Um aplicativo/bot criado no Discord Developer Portal.
- Acesso de administrador ao servidor para instalar/configurar o bot.
- Um local de hospedagem que mantenha o processo Node.js ativo. A Vercel não é indicada para manter um bot Discord Gateway conectado continuamente.

## 1. Criar o bot no Discord

1. Abra https://discord.com/developers/applications
2. Clique em **New Application** e nomeie `ESPANHA BOT`.
3. Entre em **Bot** e clique em **Reset Token** / **View Token** para copiar o token. Guarde-o em segredo.
4. Em **OAuth2 > URL Generator**, marque os escopos `bot` e `applications.commands`.
5. Em permissões, selecione `View Channels`, `Send Messages`, `Embed Links`, `Read Message History` e `Use Application Commands`. Gere o link e adicione o bot ao seu servidor.
6. Em **General Information**, copie o Application ID. Esse é o `CLIENT_ID`.
7. Copie o ID do servidor, dos canais e do cargo de staff. No Discord, ative **Configurações > Avançado > Modo desenvolvedor**; depois use **Copiar ID**.

## 2. Configurar

1. Descompacte o projeto.
2. Faça uma cópia de `.env.example` com o nome `.env`.
3. Preencha `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID`, `STAFF_ROLE_ID`, `QUEUE_CHANNEL_ID` e `MATCH_CHANNEL_ID`.
4. No canal de filas, permita ao bot ver o canal, enviar mensagens, incorporar links e ler o histórico.
5. No canal de partidas, dê as mesmas permissões.
6. Restrinja o canal de staff e os logs a cargos confiáveis.

**Nunca publique o arquivo `.env` nem envie o token em chats, prints ou repositórios.** Se vazar, regenere o token no Developer Portal.

## 3. Instalar e iniciar

No computador ou terminal do ambiente de hospedagem, dentro da pasta do projeto:

```bash
npm install
npm run register
npm start
```

`npm run register` publica os comandos slash no servidor configurado. Deixe `npm start` executando para o bot ficar online.

No iPhone, pode editar arquivos em um ambiente de desenvolvimento no navegador, mas a instalação inicial é mais simples num computador. A hospedagem deve suportar processos Node.js persistentes e armazenamento de arquivos. Se o armazenamento for temporário, `data.json` poderá ser perdido quando o serviço reiniciar; use armazenamento persistente ou faça backup.

## 4. Usar no servidor

- `/painel` — publica o painel de filas. Requer permissão de administrador do servidor e cargo staff configurado.
- Botões `Entrar X1`, `Entrar X2`, `Entrar X3`, `Entrar X4` — escolhe a modalidade e depois o valor cadastrado.
- `Ver fila` — mostra o total de jogadores aguardando.
- `Sair da minha fila` — remove o jogador da fila atual.
- `/fila modo:X1` — consulta uma modalidade.
- Quando a fila completa, o bot cria uma partida e divide os jogadores aleatoriamente em duas equipes.
- `/partida id:1` — consulta uma partida.
- `/resultado id:1 vencedor:A prova:link-ou-descricao` — participante ou staff envia o resultado para revisão.
- A staff usa **Confirmar resultado** ou **Marcar para revisão** no post da partida.

## 5. Segurança e limitações desta versão

- Os resultados não são confirmados automaticamente; somente a staff com o cargo configurado ou permissão `ManageGuild` pode confirmar.
- O bot não recebe Pix, não verifica pagamentos e não movimenta dinheiro. Os valores são apenas rótulos escolhidos na fila.
- A persistência inicial é em `data.json`, adequada apenas a um protótipo pequeno. Faça backups e não execute várias instâncias do bot usando o mesmo arquivo.
- Para uso público maior, migre para PostgreSQL e adicione transações, proteção contra concorrência, auditoria e recuperação de falhas.
- Não há sistema automático de cancelamento por ausência, expulsão de jogador ou distribuição de premiação nesta versão.
- A divisão de equipes é aleatória e deve ser conferida pelos jogadores antes de começar.
- Defina regras públicas para disputas, provas, cancelamentos e reembolsos antes de usar partidas com valores monetários.
- Não use valores de entrada até que a organização tenha verificado a legalidade e as condições aplicáveis. Este bot não processa nem guarda dados de pagamento.
